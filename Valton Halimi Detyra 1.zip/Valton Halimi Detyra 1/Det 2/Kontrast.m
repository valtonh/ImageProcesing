function y = Kontrast(I, x1, x2, y1, y2)
[M N] = size(I);
K=uint8(zeros(M, N));
% Inicalizojme nje matrice zero te gjatsis se imazhit hyres
if ( x1>=0 && x1<=255 && x2>=0 && x2<=255 && y1>=0 && y1<=255 && y2>=0 && y2<255 && x1<x2 && y1<y2 )
    for i=1:M
        for j=1:N
        %Implementimi i funksionit i dhene ne detyr.
            x=I(i,j);
            if(x>=0 && x<=x1)
                K(i,j)=(y1/x1)*x;
            elseif (x>x1 && x<x2)
                K(i,j)=(y2-y1)/(x2-x1)*x+y1;
            else(x>=x2 & x<=255)
                K(i,j)=(255-y2)/(255-x2)*x+y2;
            end
        end
    end
else
    disp('Parametrat gabim');
end
%paraqitja e ndryshimeve
imshow(I), title('Imazhi origjinal'), figure, imhist(I), title('Histogrami i imazhit hyres'), figure, imshow(K), title('Imazhi dales'),figure, imhist(K), title('Histogrami i imazhit dales');
y=K;