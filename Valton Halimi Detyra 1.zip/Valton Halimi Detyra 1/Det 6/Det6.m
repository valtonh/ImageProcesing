function f = test6(m, Ds1, Ds2)
L = imread('lena.tif');
% maska
m = ones(m, m);
% Therrasim funksionin
F = fLoG(m, Ds1, Ds2);
% Filtrojme imazhin duke perdorur filtrin F
IF = imfilter(L, F);
imshow(L),title('Origjinali'), figure, imshow(IF,[]),title('Me Filtrim')