function h=DoG(x,y,Ds1,Ds2)
a=Gauss(x,y,Ds1)-Gauss(x,y,Ds2);
h=a;