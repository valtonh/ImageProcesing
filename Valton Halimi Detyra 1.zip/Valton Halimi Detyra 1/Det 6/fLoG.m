function h=fLoG(I,Ds1,Ds2)
[M N]=size(I);
h=zeros(M,N);
for x=1:M
    for y=1:N
        h(x,y)=DoG(x,y,Ds1,Ds2);
    end
end
