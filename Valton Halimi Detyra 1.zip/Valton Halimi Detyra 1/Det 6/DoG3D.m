function s=DoG3D(x,y,Ds1,Ds2)
N=3.0;
x=linspace(-N,N);
y=x;
[X,Y]=meshgrid(x,y);
Z=DoG(X,Y,Ds1,Ds2);
surf(X,Y,Z),title('Vizualizimi 3D')