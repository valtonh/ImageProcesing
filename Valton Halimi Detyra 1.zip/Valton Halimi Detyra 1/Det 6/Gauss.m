function d=Gauss(x,y,Ds)
G=(1./(2.*pi.*Ds.^2)).*exp(-(x.^2 + y.^2)./(2.*Ds.^2));
d=G;