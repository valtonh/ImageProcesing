function y = Figura
% Krijojme imazhin te cilin e kerkon detyra
I=ones(256);
for i=1:256
    for j=1:256
        if i>=j
            I(i,j)=0;
        end
    end
end

%Veprojm se pari me operator te Laplasit, pastaj me operatorin qe eshte
%krijuar
F=fspecial('laplacian', 0.5);
D=imfilter(I, F);
A=I-D;

%Operatori yne qe nxorrem 
F1=[0 0 -2; 0 4 0; -2 0 0];
D1=imfilter(I,F1);
A1=I-D1;


%Ne kete mwnyre shfaqen imazhet dhe mund te vrehen dallimet%
imshow(I),title('Imazhi origjinal'),figure, imshow(D),title('D'), figure, imshow(A) ,title('A'), figure, imshow(D1),title('D1'),figure, imshow(A1),title('A1')
end