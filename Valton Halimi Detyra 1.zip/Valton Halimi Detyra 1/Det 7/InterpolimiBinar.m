function f=InterpolimiBinar(I,m,n)
I=I(:,:,1);%shtresa e pare e imazhit
[z w]=size(I);%madhesia e imazhit
I=im2double(I);%konverton imazhin ne tipin double

y=zeros(z,w);

for i=1:z
    for j=1:w
        
        v=[i,j,1]*[1 tand(m) 0;tand(n) 1 0;0 0 1];
        y(round(v(1)),round(v(2)))=I(i,j);
    end
end
f=imshow(y,[]),title('InterpolimBinar');
