%Funksioni kthen nje imazh "I"  te hirte ne imazh te hirte me x vlera.
%x mund te marr vleren 128, 32, 8 dhe 2.
function y=Reduktimi(I,x)
I=rgb2gray(I);
%imazhi konvertohet ne imazh te hirte
c=zeros(size(I));
switch(x)
   case 128
       [M,N]=gray2ind(I,128);
       imshow(M,N)
       % y=gray2ind(I,128);
    case 32
       [M,N]=gray2ind(I,32);
       imshow(M,N)
       %y=gray2ind(I,32); 
    case 8
       [M,N]=gray2ind(I,8);
       imshow(M,N)
       %y=gray2ind(I,8);
    case 2
       [M,N]=gray2ind(I,2);
       imshow(M,N)
       %y=gray2ind(I,2);
    otherwise
      fprintf('Gabim ne hyrje');
end