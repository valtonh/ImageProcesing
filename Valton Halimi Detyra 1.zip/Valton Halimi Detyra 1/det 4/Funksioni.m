function y=Funksioni(I,E,K0,K1,K2,N) 
M=double(I(:)); 
m=Mean(M,N);            
ds=DSL(M,N);           
Mg=mean2(I);                    
Dg=std2(I);

if ((m<=K0*Mg)&(K1*Dg<=ds<=K2*Dg)) 
    y=E*I; 
else 
    y=I; 
end
imshow(I),title('Origjinale'),figure,imshow(y),title('Pas Filterit');
