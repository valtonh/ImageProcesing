function y=Mean(x,n) 
a=1/n; 
f=0; 
for i=1:n 
    f=f+x(i); 
end 
mean=a*f;
y=mean;