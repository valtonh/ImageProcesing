function y=DSL(A,n)  
f=0; 
a=(1/(n-1)); 
for i=1:n 
    f=f+((A(i)-Mean(A,n)).^2); 
end 
Devijimi=sqrt(a*f); 
y=Devijimi;